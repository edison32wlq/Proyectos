package Principal;

import gui.FrmPrincipal;

public class Principal {

	public static void main(String[] args) {
		new FrmPrincipal().setVisible(true);

	}

}

package paquete;
/**
 * crear el codigo en base a la salida en pantalla 
 *  creado el 21 de Enero, 2023 a las 10:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 *
 */
public class Alumno extends Persona {
	
	private String codigo;
	/**
	 * constructor vacio que llama al constructor vacio
	 * anterior
	 */
	public Alumno() {
		super();
	}
	/**constructor
	 * 
	 * @param nombre ingresar nombre
	 * @param apellidos ingresar apellidos
	 * @param peso ingresar peso
	 * @param codigo ingresar codigo
	 */
	public Alumno(String nombre, String apellidos, double peso,String codigo)
	{
		super(nombre,apellidos,peso);
		this.codigo = codigo;
	}
	/**
	 * metodo que devuelve datos
	 * @param nombre ingresa nombre
	 * @param apellidos ingresa apellidos
	 * @param peso ingresa peso
	 * @param codigo ingresa codigo
	 * @return devuelve cadena de datos
	 */
	public String devolverDatos2
	(String nombre,String apellidos,double peso,String codigo) {
		
		return "nombre: " + nombre + "  apellidos: " + apellidos 
				+ "  peso: " + peso+ ", codigo: " + codigo;
	}
	
	
	
	

}

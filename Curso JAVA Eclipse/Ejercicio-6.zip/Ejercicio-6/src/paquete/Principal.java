package paquete;
/**
 * crear el codigo en base a la salida en pantalla 
 * clase para presentar los datos 
 * creado el 21 de Enero, 2023 a las 10:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 *
 */
public class Principal {

	public static void main(String[] args) {
		
		Persona p = new Persona();
		Alumno a = new Alumno();
		System.out.println(p.devolverDatos(null,null,70.5));
		System.out.println(p.devolverDatos("Pepe",null,70.5));
		System.out.println(p.devolverDatos("Pepe","P�rez",70.5));
		System.out.println(a.devolverDatos2(null,null,70.5,null));
		System.out.println(a.devolverDatos2(null,null,60.1,null));
		System.out.println(a.devolverDatos2(null,null,60.1,"0101"));
		System.out.println(a.devolverDatos2("Juana",null,60.1,"0101"));
		System.out.println(a.devolverDatos2("Juana","Coello",60.1,"0101"));
		
		
	}
}

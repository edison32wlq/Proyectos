
package paquete;
/**
 * crear el codigo en base a la salida en pantalla 
 *  creado el 21 de Enero, 2023 a las 10:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 *
 */
public class Persona {

	protected String nombre;
	protected String apellidos;
	protected double peso;
	/**
	 * constructor vacio
	 */
	public Persona() {
	}
	/**
	 * constructor en el cual se ingresa el valor de las
	 * variables 
	 * @param nombre se ingresa el nombre de Persona
	 * @param apellidos se ingresa el apellido de Persona
	 * @param peso se ingresa el peso de Persona
	 */
	public Persona(String nombre,String apellidos,double peso) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.peso = peso;
	}
	/**
	 * metodo para que mostraran los datos en pantalla 
	 * si es llamado
	 * @param nombre ingresar el nombre
	 * @param apellidos ingresar el apellido
	 * @param peso ingresar el peso
	 * @return retornara los datos
	 */
	 public String devolverDatos(String nombre,String apellidos, double peso) {
		 return "nombre: " + nombre + "  apellidos: " + apellidos + "  peso: " + peso;
	 }
}

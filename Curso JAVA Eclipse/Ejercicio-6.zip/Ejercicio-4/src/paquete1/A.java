package paquete1;
/**
 *  clase para poner la visibilidad correcta en 
 *  cada atributo de clase
 *   
 *  creado el 19 de Enero, 2023 a las 17:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 *
 */
public class A {
	protected int at1;
	private int at2;
	int at3;
	
}


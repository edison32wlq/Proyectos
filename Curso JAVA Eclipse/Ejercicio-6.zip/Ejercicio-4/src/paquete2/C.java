package paquete2;

import paquete1.A;
/**
 *  clase ver si la visibilidad es correcta
 *   
 *  creado el 19 de Enero, 2023 a las 17:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 *
 */
public class C extends A {
	/**
	 * Constructor en donde se comprobara si
	 * la visibilidad era correcta
	 */
	public void reset() {
		at1 = 0; //OK
		at2 = 0; //ERROR
		at3 = 0; //ERROR
	}
}


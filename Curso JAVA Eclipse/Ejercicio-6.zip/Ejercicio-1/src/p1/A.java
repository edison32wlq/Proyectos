package p1;

/**
 *  clase en la cual se deben encontrar lo errores 
 *  y mostrar la solucion a estos
 *   
 *  creado el 19 de Enero, 2023 a las 16:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 */
public class A {
	int a1;
	/**
	 * constructor de la clase A
	 * @param a1 ingresar un valor
	 */
	public A(int a1) {
	this.a1 = a1;
	}
}

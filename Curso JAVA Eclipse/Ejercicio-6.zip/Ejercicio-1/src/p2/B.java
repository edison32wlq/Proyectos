package p2;
import p1.A;
/**
 * clase en la cual se deben encontrar lo errores 
 * y mostrar la solucion a estos
 *  
 * creado el 19 de Enero, 2023 a las 16:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 */
public class B extends A {
	private int b1;
	
	/**
	 * 	constructor de la clase B el cual llama al 
	 * constructor anterior
	 * 
	 * @param v  ingresar el valor de v
	 * @param a1 ingresa el valor de a1
	 */
	public B(int v, int a1) {
		super(a1);
		a1 = v;
		b1 = v;
	}
}


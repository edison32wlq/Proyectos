package Clases;
/**
 * crear la clase para verificar que el otro sea 
 * correcto
 *  creado el 19 de Enero, 2023 a las 16:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 *
 */
public class B extends A{
	private int b1;
	public B(int a1, int a2, int b1) {
		super(a1,a2);
		this.b1 = b1;
	}
	/**
	 * constructor donde se llama al constructoranterior 
	 * con super y se ingresa a1 y b1
	 * @param a1
	 * @param b1
	 */
	public B(int a1, int b1) {
		super(a1);
		this.b1 = b1;
	}
	/**
	 * constructor donde se llama al constructor anterior 
	 * con super y se ingresa b1
	 * @param b1
	 */
	public B(int b1) {
		super();
		this.b1 = b1;
	}
	/**
	 *  metodo get con el cual se captura b1
	 * @return se tetorna b1
	 */
	public int getB1 () {
		return b1;
	}
	/**
	 * metodo set con el cual se envia b1.
	 * @param se ingresa valor b1
	 */
	public void setB1(int b1) {
		this.b1 = b1;
	}
}

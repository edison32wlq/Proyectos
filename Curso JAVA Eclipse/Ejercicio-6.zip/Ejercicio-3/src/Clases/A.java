package Clases;
/**
 * crear la clase para verificar que el otro sea 
 * correcto
 *  creado el 19 de Enero, 2023 a las 16:30 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 */
public class A {
	private int a1;
	private int a2;
	/**
	 * constructor vac�o
	 */
	public A() {	
	}
	/**
	 * constructor de la clase A
	 * @param variable donde se ingresa a1
	 */
	public A(int a1) {
		this.a1 = a1;
	}
	/**
	 * constructor donde se ingresa a1 y a2
	 * @param a1 variable donde se ingresa a1
	 * @param a2 variable donde se ingrsa a2
	 */
	public A(int a1, int a2) {
		this.a1 = a1;
		this.a2 = a2;
	}
	/**
	 * metodo get donde se captura a1
	 * @return retorna a1
	 */
	public int getA1() {
		return a1;
	}
	/**
	 * metodo set donde se envia a1
	 * @param a1 se ingresa valor de a1
	 */
	public void setA1(int a1) {
		this.a1 = a1;
	}
	/**
	 * metodo donde se captura a2
	 * @return se retorna a2
	 */
	public int getA2() {
		return a2;
	}
	/**
	 * metodo donde se envia a2
	 * @param a2 se ingresa valor a2
	 */
	public void setA2(int a2) {
		this.a2 = a2;
	}
}

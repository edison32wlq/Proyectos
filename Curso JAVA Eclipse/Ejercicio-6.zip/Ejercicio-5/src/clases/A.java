
package clases;
/**
 *  clase en la cual se deben encontrar lo errores 
 *  y mostrar la solucion a estos
 *   
 *  creado el 19 de Enero, 2023 a las 18:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 *
 */
public class A {
	/**
	 * constructor vacio 
	 */
	public A() {
		
	}
	/**
	 * constructor el cual imprime en pantalla
	 * el mensaje
	 */
	public void m1() {
		System.out.println("A:m1");
	}
	/**
	 * constructor que ayuda a marcar
	 * correctamente la variable m1
	 */
	public void m1Public() {
		this.m1();
	}
}



package clases;
/**
 * presenta datos ingresados 
 *  creado el 19 de Enero, 2023 a las 18:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 */
public class B extends A {
	private int b1;
	/**
	 * constructor vacio
	 */
	public B() {
	}
	/**
	 * constructor sobrecargado que ingresa el 
	 * vlaor de la variable b1
	 * @param b1 ingresa un valor entero
	 */
	public B(int b1) {
		this.b1 = b1;
	}
	/**
	 * override de reemplazo del metodo m1
	 */
	@Override
	public void m1() {
		System.out.println("B:m1");
	}
	/**
	 * metodo que no retorna nada solo presenta
	 * el mensaje
	 */
	public void m2() {
		System.out.println("B:m2");
	}
}


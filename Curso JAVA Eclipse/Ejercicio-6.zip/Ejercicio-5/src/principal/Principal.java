
package principal;

import clases.*;
/**
 * presenta datos ingresados  
 *  creado el 19 de Enero, 2023 a las 18:00 horas
 * @author Edison Wilfrido Lude�a Quichimbo
 * @version POO - 2023
 *
 */
public class Principal {
	public static void main(String[] args) {
		A obj1 = new A();
		B obj2 = new B();
		obj1.m1();
		obj2.m1();
		obj2.m2();
	}
}


